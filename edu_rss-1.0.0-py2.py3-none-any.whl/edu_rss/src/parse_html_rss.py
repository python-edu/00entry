import requests
from bs4 import BeautifulSoup

URL = {1: "https://www.bbc.co.uk/news/10628494",
       2: 'https://rss.feedspot.com/best_rss_feeds/'}


def get_rss_content(url):
    headers = {
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 "
                       "Safari/537.36"),
    }
    req = requests.get(url, headers=headers, allow_redirects=True)
    return req.content


def get_rss_channel_list(content):
    soup = BeautifulSoup(content)
    rss = soup.find_all('a', class_="ext text-blue wb-ba")
    rss = [it.get('href') for it in rss if len(it) > 0]
    return rss


def main(i=2):
    # url = 'https://rss.feedspot.com/best_rss_feeds/'
    url = URL[i]
    content = get_rss_content(url)
    rss_list = get_rss_channel_list(content)
    return rss_list
