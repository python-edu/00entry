"""Function for rss channels"""

import requests
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from collections import OrderedDict
from datetime import datetime


def get_rss_content(url):
    headers = {
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 "
                       "Safari/537.36"),
    }
    req = requests.get(url, headers=headers, allow_redirects=True)
    return req.content


def date_processing(date: str):
    dt = parsedate_to_datetime(date)
    return dt.strftime('%Y-%m-%dT%H:%M:%S')


def get_list_items(content):
    res = []
    names = ("pubDate", "title", "link", "description")
    gen_dic = lambda: OrderedDict({k: None for k in names})

    root = ET.fromstring(content)

    for it in root[0].findall('item'):
        #{"pubDate": None, "title": None, ...}
        tags = gen_dic()
        for tag in tags:
            txt = it.findtext(tag, False)
            if tag == "pubDate":
                txt = date_processing(txt) if txt else '-'
            
            if tag == "description" and '<img' in txt:
                txt = '-'
            tags[tag] = txt
            # breakpoint()
            del txt

        msg = [f"{k+':': <14}{v}" for k, v in tags.items()]
        msg = '\n'.join(msg) + "\n"
        res.append((tags["pubDate"], msg))

    res = sorted(res,
                 key=lambda it: datetime.fromisoformat(it[0]),
                 reverse=True)
    res = [it[1] for it in res]
    return res 


