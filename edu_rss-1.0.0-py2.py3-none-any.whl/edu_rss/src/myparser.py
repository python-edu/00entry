import argparse

# local import
from edu_rss.src.channel_list import RSS_CHANNELS


def parse_args():
    parser = argparse.ArgumentParser(
                        prog='myrss',
                        description='Simple edu rss reader',
                        epilog='END')
    parser.add_argument('-u', '--url',
                        type=str,
                        help="Url for rss source channel",
                        default='bbc_news')

    parser.add_argument('-l', '--list_url',
                        help="Show list of predefined urls",
                        action="store_true")

    return parser.parse_args()



def args_processing(args):
    if args.url.strip() in RSS_CHANNELS.keys():
        args.url = RSS_CHANNELS.get(args.url)
    
    return args
