RSS_CHANNELS = {
        'bbc_news':
        "https://feeds.bbci.co.uk/news/science_and_environment/rss.xml",
        
        "bbc_science":
        "https://feeds.bbci.co.uk/news/science_and_environment/rss.xml",
        }
