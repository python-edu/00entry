import requests
from bs4 import BeautifulSoup

# local imports
from edu_rss.src import myparser
from edu_rss.src import rss_func as fn

# url = "https://rss.feedspot.com/best_rss_feeds/"
# req = requests.get(url)
# 
# soup = BeautifulSoup(req.content, "html.parser")


def main(args):
    if args.list_url:
        for key, val in myparser.RSS_CHANNELS.items():
            print(f"{key}:\n    {val}\n")
        # sys.exit()
        return
    else:
        print(args)

    content = fn.get_rss_content(args.url)
    msgs_list = fn.get_list_items(content)
    for it in msgs_list:
        print(it)

def cli():
    args = myparser.parse_args()
    args = myparser.args_processing(args)
    main(args)



if __name__ == '__main__':
    cli()
