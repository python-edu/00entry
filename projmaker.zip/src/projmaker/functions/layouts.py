"""
Tworzy strukturę katalogów.

"""

import textwrap
from pathlib import Path


class SrcLayout:
    """
       myproj/
             |pyproject.toml
             |requirements.txt
             |README.md
             |src/
                 |
                 |myproj/
                        |__init__.py
                        |main.py
                        |modules/
                                |__init__.py
    """

    def __init__(self, root: str|Path, args):
        ...



class FlatLayout(SrcLayout):
    """
       myproj/
             |pyproject.toml
             |requirements.txt
             |README.md
             |myproj/
                    |__init__.py
                    |main.py
                    |modules/
                            |__init__.py
    """
    ...
