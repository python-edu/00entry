"""
...
"""

import sys
from pathlib import Path
from pprint import pp

# local import
from make_proj.myparser import args_parser
from make_proj.functions import layouts as ly
from make_proj.functions import helpers as hlp


def main():
    ...



if __name__ == "__main__":
    main()
