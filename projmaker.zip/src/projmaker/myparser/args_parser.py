import argparse
import re
import sys
from pathlib import Path
import textwrap

# local import
from make_proj.functions import helpers as hlp

# --

description = textwrap.dedent("""\
        This script creates the project structure in the current directory:
          - creates directories and subdirectories
          - creates metadata files: pyproject.toml, README.md, requires.txt
          - creates __init__.py files
          - creates a virtual environment ???
    """\
            )


def myparser():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawTextHelpFormatter,
        description=description,
    )
    # parser.add_argument(...
    #   proj_name
    #   --layout: src or flat
    #   --force: del env
    # return parser.parse_args()


def args_processing(args):
    # root: current dir
    # env_prompt: nice name for the environment
    return args
